<?php


/**
 *
 * Description
 *
 *
 * @name			PACKAGE NAME
 * @see				PACKAGE REFFER URL
 * @package			PACKAGE
 * @subpackage		SUBPACKAGE
 * @author			Mahdi Pedramrazi
 * @category		backend
 * @access			Vortal Group Programming Team
 * @version			1.0
 * @since			May 28, 2010 - 2:53:08 PM 
 * @copyright		Vortal Group
 *
 * @example
 * <code>
 * <?php
 *
 *
 *
 * ?>
 * </code>
 *
 */
 
 
class FrameworkModuleLoader {
		
	public static function Loader( $className ){
		
		$path = YottaBox::GetFileSystemPath().'frameworkModules/'.$className.'.class.php';
		
		if( !file_exists( $path ) ){ return false; }
			
		require_once ( $path );
		
	}/* </ Loader >*/	
	
}


spl_autoload_register( array( 'FrameworkModuleLoader', 'Loader' ) ); // As of PHP 5.3.0


?>