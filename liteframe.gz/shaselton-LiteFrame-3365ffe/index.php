<?php
 	error_reporting(E_ALL);
    ini_set('display_errors', '1');
 	require_once(realpath('.')."/yottaBox/index.php");    
    
    $YottaBox =  new YottaBox();
   
    // if set to false, you will be unable to set folder paths to get specific templates.
 	$YottaBox->SetTemplateEngine(true);

    // There is always going to be an action that the framework is going to be pointing to.
    $YottaBox->SetPreAction("homepage");  // Set your default action here for the beginning of your project!
    

    // $YottaBox->SetPreActionWithTemplate("homepage","homepage2");
    $YottaBox->SmartyPath("/var/www/phplib/smarty_vortal/Smarty.class.php");
    
    // Grab all $yAction and make it to a json obj
     $YottaBox->JavaScriptActionInfo();
                                    
    // if you want all your javascript on the bottom of the page                                    
     //$YottaBox->JavascriptBottomPage();

     // Adding JS / CSS files with the same Action name to the DOM if they exist
     $YottaBox->AddingRelatedFilesToDOM();
    
    
     $YottaBox->SetJavascriptLibraryFolder("jslib");
     $YottaBox->SetStyleLibraryFolder("jslib");
     

	 
	 
     $YottaBox->RunApplication();
    


?>
