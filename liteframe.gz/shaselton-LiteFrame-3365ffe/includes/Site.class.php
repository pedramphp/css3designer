<?php 


/**
* @name         Site Class 
*
* @uses           Site
* @Package        Site
* @subpackage     Site
* @author        Mahdi Pedram
* @category      backend
* @access        Vortal Group  programming Team
* @version       1.0
* @since         2010 - 05 - 28  12:16 AM ( Friday )
* @copyright     Vortal Group
*
*
*
*
* Rules : 1 - Space between Each function					  :   4 Enter Breaks
*         2 - Space between First Line of From Starting Brace :   1 Enter Break
* 		  3 - Space between First Line of From Ending Brace   :   1 Enter Break
* 		  4 - Space is  :  TAB
*
*
*/


session_start(); // start up your PHP session! 

require_once(YottaBox::GetFileSystemPath()."includes/SiteHelper.class.php");


class Site extends SiteHelper{
	
	
	public function __construct(){

		try{
			
			$this->Process( func_get_args() );

		}catch ( SystemException $e ){

			echo("<pre>".print_r($e,true)."</pre>");
			exit();
		}
		

		
	} /* </ __construct >  */

	
	
	
	private function Process( $args ){

			parent::__construct();
	
			
			$requiredObjects = ObjectModule::GetArguments( $args );
			
			if(!YottaBox::IsAjax()) {  $this->LoadObjects( self::$staticObjects ); }
			
			if( !empty( $requiredObjects ) ){
	
				$this->LoadObjects( $requiredObjects );
			
			}		
		
	}/* </ Process > */
	
	
	
	
    public function LoadObjects( $requiredObjects ){
    		
          foreach($requiredObjects as $LWSObject){
          	
          	$field = lcfirst(str_replace('Site','',$LWSObject));
          	$this->GenerateObject( $LWSObject, $field );
          	          	
          }
		  $this->SetObjectsForTemplate();
         
        
    } /* </ LoadObjects >  */	
	

	
	
	private function GenerateObject($className, $field) {
		
		$this->siteObjects[$field] = new $className();
		
		self::$siteObjectsData[$field]   = $this->siteObjects[$field]->GetResults();
//		echo("<pre>".print_r(self::$siteObjectsData[$field],true)."</pre>");		
	}
	
	
	
}  /* </Site> */


?>