<?php


/**
 *
 * Description
 *
 *
 * @name			PACKAGE NAME
 * @see				PACKAGE REFFER URL
 * @package			PACKAGE
 * @subpackage		SUBPACKAGE
 * @author			Mahdi Pedramrazi
 * @category		backend
 * @access			Vortal Group Programming Team
 * @version			1.0
 * @since			May 28, 2010 - 3:14:23 PM
 * @copyright		Vortal Group
 *
 * @example
 * <code>
 * <?php
 *
 *
 *
 * ?>
 * </code>
 *
 */





/**
 *
 *	Auto Site Object Loader :
 *	Auto Loader ( Loads site objects that have not been loaded when they are called )
 *
 *  ProdoriBreadcrumb
 *  ProdoriFooter
 *  ProdoriLogin
 *  ProdoriPasswordReminder
 *  ProdoriRegistration
 *
 */
require_once(YottaBox::GetFileSystemPath()."includes/objects/siteObjects/SiteObjectLoader.class.php");


/**
 *
 *	Site Module Loader :
 *	Auto Loader ( Loads site modules that have not been loaded when they are called )
 *
 *  ObjectModule
 *  Sanitize
 *  SiteModuleLoader
 *  Tools
 *
 */
require_once(YottaBox::GetFileSystemPath()."includes/modules/SiteModuleLoader.class.php");






/**
 *
 *	Core Module Loader :
 *	Auto Loader ( Loads site modules that have not been loaded when they are called )
 *
 *	Users
 *
 */
require_once(YottaBox::GetFileSystemPath()."includes/objects/coreObjects/CoreObjectLoader.class.php");




/**
 *
 *	Framework Module Loader :
 *	Auto Loader ( Loads site modules that have not been loaded when they are called )
 *
 *	Redirect
 *
 */
require_once(YottaBox::GetFileSystemPath()."frameworkModules/FrameworkModuleLoader.class.php");


?>