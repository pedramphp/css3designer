<?php

/*
 * Auto Loader ( Loads Site Objects , framework Modules , 
 * 				 site Modules ,core Objects Automatically when the system needs it)
 * 
 */

require_once(YottaBox::GetFileSystemPath()."includes/GeneralModuleLoader.class.php");

/**
 * Configuration values
 */
require_once(YottaBox::GetFileSystemPath()."configs/Configurations.php");

require_once(YottaBox::GetFileSystemPath()."includes/SiteSettings.class.php");

require_once(YottaBox::GetFileSystemPath()."includes/modules/debugging/Debug.class.php");

require_once(YottaBox::GetFileSystemPath()."includes/objects/coreObjects/CoreExceptions.class.php");


class SiteHelper {
	
	static  $staticObjects = array("SiteFooter","SiteHeader");
	static  $tools;
	public  static $siteObjectsData = null;
	private $ajaxRequest = false;	
	static public  $debugger;
	
	public function __construct(){
	
		$this->SiteSettings();
		$this->UserSettings();

		SiteHelper::Debug('---------------------------------------'); 
		
		SiteHelper::Debug('Site Object Loading Complete'); 
		SiteHelper::Debug("Here's some data, have fun!!"); 
		SiteHelper::Debug("Session Data", $_SESSION); 
		SiteHelper::Debug("Cookie Data", $_COOKIE); 
		SiteHelper::Debug('---------------------------------------'); 
		
	}  /* </ __construct >  */
	
	
	
	public function SiteSettings(){
	
		
		$siteSettings = new SiteSettings();
		$siteSettings->SetTemplate();
		$siteSettings->SetTemplateColor();
		$siteSettings->SetCoreJavascript();
		
		
	}	/*  </ SiteSettings >  */

	
	
	
	private function UserSettings(){
		/*
		Users::Initialize();
		self::$siteObjectsData['User'] = array();
		self::$siteObjectsData['User']['LoginStatus'] = false;
		
		if( Users::ISLoggedIn()){

			self::$siteObjectsData['User']['LoginStatus'] = true;
			 self::$siteObjectsData['User']['Data'] = Users::FetchUserRecordArray();
			
			
		}
		$this->SetObjectsForTemplate();
		*/
				
	}/* </ UserSettings > */
	
	
	
	
	public function SetObjectsForTemplate(){
		
		YottaBox::$yAction['SiteData'] =  self::$siteObjectsData;
		
	} /* </ SetObjectsForTemplate >  */	
	

	
	
	public function SetDebugger(){
		
		// the first parameter is if you want debugging on.
		// the second parameter is if you have firePHP installed on your browser.
		self::$debugger = Debug::getInstance(true, true);
		
	}  /* </ SetDebugger >  */
	
	
	
	
	public static function Debug($message,$variable = null , $printArray = false){
		
		if($printArray === true){
			
			echo ("<pre>".print_r($message,true)."</pre>");
			echo ("<pre>".print_r($variable,true)."</pre>");
			return;
		
		}
		self::$debugger->debug($message, $variable);
		
	}  /* </ Debug >  */
	
	
	
	public static function SubHeaderTitle( $title ){
		
		self::$siteObjectsData['subHeaderTitle'] = $title;
		
		
	}/* </ SubHeaderTitle >  */
	
	
	
	public static function SubHeaderDescription( $description ){
		
		self::$siteObjectsData['subHeaderDescription'] = $description;
		
	}/* </ SubHeaderDescription >  */
	
	
	
} /* </ SiteHelper >  */	



SiteHelper::SetDebugger();

?>