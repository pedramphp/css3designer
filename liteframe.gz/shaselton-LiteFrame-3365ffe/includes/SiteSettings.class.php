<?php


/**
 *
 * Description
 *
 *
 * @name			PACKAGE NAME
 * @see				PACKAGE REFFER URL
 * @package			PACKAGE
 * @subpackage		SUBPACKAGE
 * @author			Mahdi Pedramrazi
 * @category		backend
 * @access			Vortal Group Programming Team
 * @version			1.0
 * @since			May 28, 2010 - 11:38:07 AM 
 * @copyright		Vortal Group
 *
 * @example
 * <code>
 * <?php
 *
 *
 *
 * ?>
 * </code>
 *
 */
class SiteSettings {
	
	static public $tools;
	public function __construct(){}
	
	
	
	public function SetTemplate(){
		YottaBox::SetTemplateFolderName("default");
		YottaBox::SetTemplateColorName("dark");
		self::$tools = new Tools();
		
	}/* </ SetTemplate > */
	
	
	
	
	public function SetTemplateColor(){
		
		YottaBox::IncludeStyle('default.css');
		
	} /* </ SetTemplateColor > */
	
	
	
	public function SetCoreJavascript(){
		
		YottaBox::IncludeLibraryJavascript('jquery/jquery-1.4.2.min.js');
		YottaBox::IncludeLibraryJavascript('jquery/jquery.fileLoader.js');
		YottaBox::IncludeLibraryJavascript('jquery/jquery.module.js');
		YottaBox::IncludeJavascript('modules.js');
		
	} /* </ SetCoreJavascript > */
	
	
	
} /* </ SiteSettings > */
	
?>