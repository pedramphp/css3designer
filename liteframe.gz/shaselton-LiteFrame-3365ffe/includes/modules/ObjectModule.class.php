<?php


/**
 *
 * Description
 *
 *
 * @name			PACKAGE NAME
 * @see				PACKAGE REFFER URL
 * @package			PACKAGE
 * @subpackage		SUBPACKAGE
 * @author			Mahdi Pedramrazi
 * @category		backend
 * @access			Vortal Group Programming Team
 * @version			1.0
 * @since			Apr 28, 2010 - 10:35:23 AM 
 * @copyright		Vortal Group
 *
 * @example
 * <code>
 * <?php
 *
 *
 *
 * ?>
 * </code>
 *
 */
 
 
class ObjectModule {
	
	public static function GetArguments($args){
		
		if(count($args) == 1 && is_array($args[0])) {  $args = $args[0]; } 
		return $args;
	
	}
	
}

?>