<?php
/**
 *
 * LICENSE
 *
 * This source file is subject to the GPL license that is bundled
 * with this package in the file LICENSE.txt.
 *
 * @package    YottaBox
 * @copyright  Copyright (c) 2009 through 2010, Mahdi Pedramrazi
 * @license    http://www.gnu.org/licenses/gpl.txt     GPL  
 * 
 * 
 * A class that is treated as Framework
 *  
 * @author     Mahdi Pedramrazi <pedramphp@gmail.com>
 * @author	   Scott Haselton <shaselton@gmail.com>
 * @version    1.0 beta
 * @date       Sep 10th 2009
 *   
 */

class  YottaBox {

    public  static $yAction;
    public  $logFolder          = "log/";
    public  $cssFolder          = "css/";
    public  $javascriptFolder   = "javascript/";
    public  $javascriptModuleFolder   = "module/";
    public  $javascriptLibraryFolder   = "library/";
    public  $styleLibraryFolder = "library/";
    public  $styleFolder        = "style/";    
    public  $stylePath;
    public  $imagePath;         
    public  $includeFolder      = "includes/";
    public  $actionFolder       = "actions/";
    public  $layoutFolder       = "layouts/";
    public  $settingsFolder     = "_settings/";
    public  $imagesFolder       = "images/";
    public  $templateFolder     = "templates/";
    public  $templateCFolder    = "templates_c/";
    public  $templateCacheFolder = "cache/";
    public  $templateConfigFolder = "configs/";
    public  $actionQuerystring = "action";
    public  $smartyPath        = '/home/pedramte/phplib/Smarty/Smarty.class.php';    // Set Smarty Path;
    public  $templateEngineFolder = '';
    public  $templateEngine    = false ;
    public  $templateColorName = '';
    public  $action = false;
    public  $templateAction;
    public  $templateLayoutName = 'index';
    public  $actionType = 'HTML';
    public  $actionTrigger;
    public  $applicationPath;
    public  $fileSystemPath;
    public  $fileSystemPaths;
    public  $javaScriptActionInfo = false;
    public  $javascriptBottomPage = false;
    public static $logFilePath;
    public $RelatedFiles = false;
    public $yActionJson;
    
    
    
    
    public function __construct(){
  		
          date_default_timezone_set('UTC');
  	
    }  // Construction End	
	
    
    
    
    public  function RunApplication(){
    	
		if(!$this->action){ die ("Set the PreAction Before Running The Application");  }
        $this->SetPaths();
       
        $this->UpdateFoldersPaths();
      
		$this->Action();
	
    }
	
    
    
    
    public  function Action(){
	                                                                                             
       $this->SetRequestVariables();                  
       $this->SetAction();   
       $this->UpdateyAction(); 
        
      
       $path = $this->fileSystemPath.$this->actionFolder.self::$yAction['_YOTTA_']['ACTION'].".php";
        
       if(!file_exists ( $path )){ die ("File <b>".$path." </b> <br />Not Found or File doesn't have the permission to open");      }
       
       require_once($path);

       	
       $YottaBoxAction = new YottaBoxAction();
       self::$yAction['_YOTTA_']['VARS']['Request'] = self::$yAction['_YOTTA_']['REQUEST'];
       $this->yottaVars = &self::$yAction['_YOTTA_']['VARS'];
       // Double checking the Template variables from the Action file
       $this->MergeActionTemplatesWithFramework();
       $this->LoadTemplate();	  

	}
	
	
	
    
    
    
    public function LoadTemplate(){

        $this->SetActionTrigger();
        $this->UpdateFoldersPaths();
        if($this->RelatedFiles){  $this->CreateRelatedFiles(); } 
    	if($this->javaScriptActionInfo){ $this->yottaVars['javaScriptActionInfo'] = json_encode($this->yottaVars); }
        require_once ($this->smartyPath);
		
        
		$smarty = new Smarty;
        $smarty->template_dir = $this->fileSystemPath.$this->templateFolder;
        $smarty->compile_dir  = $this->fileSystemPath.$this->templateCFolder;
        $smarty->cache_dir    = $this->fileSystemPath.$this->templateCacheFolder;
        $smarty->config_dir   = $this->fileSystemPath.$this->templateConfigFolder;
        $smarty->left_delimiter = '<!--{';
        $smarty->right_delimiter = '}-->';

        $smarty->assign("ALL_VARS",self::$yAction);
        $smarty->assign(self::$yAction);
        $display = $this->GetDisplay();
        if($display == false) return;        
        $smarty->display($display) ;               
		
    }

    
    
    
/****************************************
*           TOOLS   
*****************************************/


	
	public  function SetPaths(){ 
	   
       $this->fileSystemPath = realpath('.')."/";
       $this->logFilePath =  $this->fileSystemPath.$this->logFolder; 
 
        $this->applicationPath = 'http://' . $_SERVER['SERVER_NAME'] . dirname($_SERVER['SCRIPT_NAME'])."/";
        $this->fileSystemPaths['basePath']     = $this->fileSystemPath;
        $this->fileSystemPaths['actionPath']   = $this->fileSystemPath . $this->actionFolder;
        $this->fileSystemPaths['templatePath'] = $this->fileSystemPath . $this->templateFolder;           
    
    }
    

    
    
    public function UpdateyAction(){
	   
	   $this->UpdateyActionVariables();
       self::SetTemplateAction($this->templateAction);
	   
	}
    
    
    
    
    public function UpdateyActionVariables(){ self::$yAction['_YOTTA_']['VARS'] = get_object_vars($this);  }
    
    
    
    
    public  function GetTemplateName(){    return self::$yAction['_YOTTA_']['VARS']['templateAction'];  }           	

    
    
    
    public function GetDisplay(){
        
        $display = $this->layoutFolder.$this->templateEngineFolder.$this->templateLayoutName.'.tpl.html';
        switch($this->actionType){
            case "AJAX" : 
              $display = self::$yAction['_YOTTA_']['VARS']['actionTrigger'];
              break;
              
            case "JSON" : 
            	
              echo json_encode(self::$yAction);
              return false;
              break;
              
               
            case "None":
                return false;
                break;
            
        }
        return $display;  
        
    }
    
    
    
    
    public function UpdateFoldersPaths(){
        
        $this->fileSystemPaths['templateActionPath'] = 
        $this->yottaVars['fileSystemPaths']['templateActionPath'] = 
        $this->fileSystemPaths['templatePath'].$this->actionFolder.$this->templateEngineFolder;
 
        $this->fileSystemPaths['templateIncludePath'] = 
        $this->yottaVars['fileSystemPaths']['templateIncludePath'] = 
        $this->fileSystemPaths['templatePath'].$this->includeFolder.$this->templateEngineFolder;
        
        $this->fileSystemPaths['templateLayoutPath'] = 
        $this->yottaVars['fileSystemPaths']['templateLayoutPath'] = 
        $this->fileSystemPaths['templatePath'].$this->layoutFolder.$this->templateEngineFolder;        

        $this->fileSystemPaths['javascriptPath'] =
        $this->yottaVars['fileSystemPaths']['javascriptPath'] = $this->fileSystemPath.$this->javascriptFolder.$this->templateEngineFolder;
        
        $this->fileSystemPaths['javascriptModulePath'] =
        $this->yottaVars['fileSystemPaths']['javascriptModulePath'] = $this->fileSystemPath.$this->javascriptFolder.$this->templateEngineFolder.$this->javascriptModuleFolder;
        
        
        $this->fileSystemPaths['stylePath'] =
        $this->yottaVars['fileSystemPaths']['stylePath'] 	  = $this->fileSystemPath.$this->styleFolder.$this->templateEngineFolder.$this->templateColorName;
        
        $this->yottaVars['actionFolder'] = $this->actionFolder.$this->templateEngineFolder;
        $this->yottaVars['includeFolder'] = $this->includeFolder.$this->templateEngineFolder;
        $this->yottaVars['layoutFolder'] = $this->layoutFolder.$this->templateEngineFolder;
        
        $this->yottaVars['stylePath'] = $this->applicationPath.$this->styleFolder.$this->templateEngineFolder.$this->templateColorName;
        $this->yottaVars['imagePath'] = $this->applicationPath.$this->styleFolder.$this->templateEngineFolder.$this->templateColorName.$this->imagesFolder;
        $this->yottaVars['javascriptPath'] = $this->applicationPath.$this->javascriptFolder.$this->templateEngineFolder;
        $this->yottaVars['javascriptModulePath'] = $this->applicationPath.$this->javascriptFolder.$this->templateEngineFolder.$this->javascriptModuleFolder;
        if(!isset($this->yottaVars['javascriptLibraryPath'])){
        	$this->yottaVars['javascriptLibraryPath'] = $this->applicationPath.$this->javascriptLibraryFolder;
        }
        if(!isset($this->yottaVars['styleLibraryPath'])){
        	$this->yottaVars['styleLibraryPath'] = $this->applicationPath.$this->styleLibraryFolder;
        }
        $this->yottaVars['javaScriptActionInfo'] = $this->javaScriptActionInfo;
        
        $this->fileSystemPaths['settingsPath'] = 
        $this->yottaVars['fileSystemPaths']['settingsPath'] = 
        $this->fileSystemPaths['templatePath'].$this->settingsFolder;
		
        if($this->actionType == "INCLUDE_JSON"){
        	$data = self::$yAction; 
        	unset($data['_YOTTA_']);
        	$this->yottaVars['yActionJson']  =  $data;    
	}
        

        
   
        
            
    }
    
    
    
    
    public function MergeActionTemplatesWithFramework(){
        
         if($this->templateEngine) { $this->SetTemplateEngineFolder();  $this->SetTemplateEngineColorName(); }
         $this->templateLayoutName = $this->yottaVars['templateLayoutName'];
         $this->actionType = $this->yottaVars['actionType'];
        
    }	
    
    
    
    
    public function SetActionTrigger(){
        
        $this->actionTrigger = 
        $this->yottaVars['actionTrigger'] = 
        $this->actionFolder.$this->templateEngineFolder.$this->GetTemplateName().".tpl.html";
 
    }
    
    
    
    
    public  function SetAction(){     

	   $request = self::$yAction['_YOTTA_']['REQUEST'];
	   if(  $this->ActionExist() ){
	       
	     $this->action = self::$yAction['_YOTTA_']['ACTION'] = $request[$this->actionQuerystring];                   
	   
       }else{  self::$yAction['_YOTTA_']['ACTION'] = $this->action;  }
      
       if(!isset($this->templateAction)){ $this->templateAction = $this->action;  }
       
    }
    
    
    
    
    public function ActionExist(){
        
        $request = self::$yAction['_YOTTA_']['REQUEST'];
	     return ( isset($request) && 
                  !empty($request) && 
                    array_key_exists($this->actionQuerystring,$request) 
                 ) ? true : false;
                 
    
    }
    
    
    
    
    public function JavascriptBottomPage(){  $this->javascriptBottomPage = true; }
       
    

    
    
	public function CreateRelatedFiles(){

		$jsFile = $this->fileSystemPaths['javascriptPath'].self::$yAction['_YOTTA_']['ACTION'].".js";
		if(file_exists($jsFile)){
			$this->yottaVars['javascriptIncludes'][] = self::$yAction['_YOTTA_']['ACTION'].".js"; 
			$this->yottaVars['javascriptIncludes'] = array_unique($this->yottaVars['javascriptIncludes']);
		}

	    
		$cssFile = $this->fileSystemPaths['stylePath'].self::$yAction['_YOTTA_']['ACTION'].".css";
		if(file_exists($cssFile)){
			$this->yottaVars['styleIncludes'][] = self::$yAction['_YOTTA_']['ACTION'].".css"; 
			$this->yottaVars['styleIncludes'] = array_unique($this->yottaVars['styleIncludes']);
		}
	    
	}    
    
    
    
 
 /*****************************************************
*           Funtions being Called by Action file    
******************************************************/     
         
	public static function SetTemplateAction($templateAction){  self::$yAction['_YOTTA_']['VARS']['templateAction'] = $templateAction;  }
	
    
    
    
    public function SetTemplateFolderName($tempalteFolder){  
   	
    	
        if(self::$yAction['_YOTTA_']['VARS']['templateEngine'] == 1 || $this->templateEngine === true){
          
            $this->templateEngineFolder = self::$yAction['_YOTTA_']['VARS']['templateEngineFolder'] = $tempalteFolder."/";
            
        }
    }
    
    
    
    
    public static function  IncludeJavascript(){
    	
    	self::IncludeFiles(func_get_args(), "javascriptIncludes");

    } 
    
    

    public static function  IncludeLibraryJavascript(){
        
    	self::IncludeFiles(func_get_args(), "javascriptLibraryIncludes");
        
    }     
    
    

    
    public static function  IncludeLibraryStyle(){
    	
    	self::IncludeFiles(func_get_args(), "styleLibraryIncludes");
        
    }    
    
    
    public static function  IncludeStyle(){
			
    	self::IncludeFiles(func_get_args(), "styleIncludes");
        
    }
    
    
    private static function IncludeFiles($args, $type){
    	
    	$includes = (isset(self::$yAction['_YOTTA_']['VARS'][$type])) 
           ? self::$yAction['_YOTTA_']['VARS'][$type]
           : array();
        if(count($args) == 1 && is_array($args[0])) {  $args = $args[0]; } 
    	self::$yAction['_YOTTA_']['VARS'][$type] = array_unique(array_merge($includes,$args));
    	
    }
    
    public static function InlineStyle($code){  self::$yAction['_YOTTA_']['VARS']['styleInline'] = $code; }     
    
    
    
    
    public static function InlineJavascript($code){  self::$yAction['_YOTTA_']['VARS']['javascriptInline'] = $code; } 
    
        

        
	public function SetTemplateColorName($tempalteFolder){  
       
        if( (self::$yAction['_YOTTA_']['VARS']['templateEngine'] == 1 && !empty(self::$yAction['_YOTTA_']['VARS']['templateEngineFolder']))
           ||	
           ($this->templateEngine === true && !empty($this->templateEngineFolder))
        ){
          
            $this->templateColorName = self::$yAction['_YOTTA_']['VARS']['templateColorName'] = $tempalteFolder."/";
            
        }
    }
    
        
    
    
	public function SetTemplateLayoutName($layout){ 

		$this->templateLayoutName = self::$yAction['_YOTTA_']['VARS']['templateLayoutName'] = $layout; 

	}
	
    
    
    
    public static function AJAXLayout(){ self::$yAction['_YOTTA_']['VARS']['actionType'] = "AJAX";  }
	
    
    
    
    public static function JSONLayout(){ self::$yAction['_YOTTA_']['VARS']['actionType'] = "JSON";  }    
    
    
    

    public static function NoTemplateLayout(){ self::$yAction['_YOTTA_']['VARS']['actionType'] = "None";  }    
    
    public static function IncludeJson(){ self::$yAction['_YOTTA_']['VARS']['actionType'] = "INCLUDE_JSON";  }  
    
    
    public function SetTemplateEngineFolder(){
      
        $this->templateEngineFolder = self::$yAction['_YOTTA_']['VARS']['templateEngineFolder'];    
         // echo $this->templateEngineFolder;
    }
    
    
    
    
    public function SetTemplateEngineColorName(){
        
        $this->templateColorName = self::$yAction['_YOTTA_']['VARS']['templateColorName']; 
    
    }

    
    
    
    public static function FetchGetVariable(){  return self::$yAction['_YOTTA_']['GET']; }
    
    

    
    public static function FetchPostVariable(){ return self::$yAction['_YOTTA_']['POST']; }

    
    
    
    public static function FetchRequestVariable(){ return self::$yAction['_YOTTA_']['REQUEST']; } 
    
    
    
    
    public static function GetFileSystemPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['fileSystemPath']; }
    public static function GetApplicationPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['applicationPath']; }
    public static function GetJavascriptPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['javascriptPath']; }
    public static function GetJavascriptModulePath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['javascriptModulePath']; }
    public static function GetStylePath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['stylePath']; }
    public static function GetImagePath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['imagePath']; }
    public static function GetJavascriptLibraryPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['javascriptLibraryPath']; }
	public static function GetStyleLibraryPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['yottaVars']['styleLibraryPath']; }
	public static function GetTemplateIncludePath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['fileSystemPaths']['templateIncludePath']; }
	public static function GetTemplateActionPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['fileSystemPaths']['templateActionPath']; }
	public static function GetTemplateLayoutPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['fileSystemPaths']['templateLayoutPath']; }
	public static function GetTemplateSettingsPath(){ return YottaBox::$yAction['_YOTTA_']['VARS']['fileSystemPaths']['settingsPath']; }
	
	
	
    public static function InlineJSON($var , $name = ''){
    	
    	$name = empty($name) ? "jsonObj" : $name  ;
    	
    	if(isset(self::$yAction['_YOTTA_']['VARS']['javascriptInline'])){
    		self::$yAction['_YOTTA_']['VARS']['javascriptInline'] += " var $name = ". json_encode($var)  . ";";
    	}else{
    		self::$yAction['_YOTTA_']['VARS']['javascriptInline'] = " var $name = ". json_encode($var)  . ";";
    	}
    	
    }
    
    
    
	public function GetVarName($var) {
		
	    foreach($GLOBALS as $var_name => $value) {
	        if ($value === $var) {
	            return $var_name;
	        }
	    }
	
	    return false;
	
	}
    
    
    
    


/****************************************
*           SET REQUESTS    
*****************************************/  



    public function SetRequestVariables(){
        
        $this->SetPostVars();
        $this->SetGetVars();
        $this->SetRequestVars();
        
    }
    
    
    
    public function SetPostVars(){

         self::$yAction['_YOTTA_']['POST'] = array();   
         if(isset($_POST) && !empty($_POST)){
             foreach($_POST as $parameter => $value){         
                 self::$yAction['_YOTTA_']['POST'][$parameter] = $this->Sanitize($value);
               }
          }       
            
        
    }



    public function SetGetVars(){

         self::$yAction['_YOTTA_']['GET'] = array();   
         if(isset($_GET) && !empty($_GET)){
             foreach($_GET as $parameter => $value){         
                 self::$yAction['_YOTTA_']['GET'][$parameter] = $this->Sanitize($value);
               }
         }       
                  
        
    }




    public function SetRequestVars(){
		
         self::$yAction['_YOTTA_']['REQUEST'] = array();   
         if(isset($_REQUEST) && !empty($_REQUEST)){
             foreach($_REQUEST as $parameter => $value){         
                 self::$yAction['_YOTTA_']['REQUEST'][$parameter] = $this->Sanitize($value);
             }
                    
         }
         
    }
    
    public function Sanitize($input){
    	return $input;
        if (is_array($input)){
            foreach($input as $var=>$value){
                $output[$var] = $this->Sanitize($value);
            }
        }else {
            if (get_magic_quotes_gpc()) {
                $input = stripslashes($input);
            }
            $output  = $this->CleanInput($input);
            //$output = mysql_real_escape_string($input); 
           }
        return $output;
        
    }
    
    
    private function CleanInput($input){
        
    	//$input = urldecode($input);
    	return $input;
    	
  		 /*  	
        $strip = array(
            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
           '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags 
            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments 
        );
        
        $output = preg_replace($strip, '', $input);
        return $output;
        */

    }

    
    
   



/********************************************
*           FUNCTIONS BEING CALL BY OBJECT    
*********************************************/           	


	public  function SetTemplateEngine($bool){      $this->templateEngine   =  $bool;	}
	
    
    
    
    public  function SetLogFolder($folder){         $this->logFolder        = $folder;	}
	
    
    
    
    public  function SetJavascriptFolder($folder){  $this->javascriptFolder = $folder;	}
    
    
    
    public  function SetJavascriptModuleFolder($folder){  $this->javascriptModuleFolder = $folder;	}
    
    
    
    public  function SetJavascriptLibraryFolder($folder){  
    	
    	if(isset(self::$yAction)){
    		
    		self::$yAction['_YOTTA_']['VARS']['javascriptLibraryFolder'] = $folder."/";
    		self::$yAction['_YOTTA_']['VARS']['javascriptLibraryPath'] = self::$yAction['_YOTTA_']['VARS']['applicationPath'].$folder."/";
    	
    	}else{
    		
    		$this->javascriptLibraryFolder = $folder.'/';
    	
    	}
    	
    }
    

    
    
    public  function SetStyleLibraryFolder($folder){  
    	if(isset(self::$yAction)){
    		
    		self::$yAction['_YOTTA_']['VARS']['styleLibraryFolder'] = $folder."/";
    		self::$yAction['_YOTTA_']['VARS']['styleLibraryPath'] = self::$yAction['_YOTTA_']['VARS']['applicationPath'].$folder."/";
    	
    	}else{
    		
    		$this->styleLibraryFolder = $folder.'/';
    	
    	}
    	
    }    
    
	
    public  function SetIncludeFolder($folder){     $this->includeFolder    = $folder;	}
	
    
    
    
    public  function SetActionFolder($folder){      $this->actionFolder     = $folder;	}
	
    
    
    
    public  function SetImagesFolder($folder){      $this->imagesFolder     = $folder;	}
	
    
    
    
    public  function SetTemplateFolder($folder){    $this->templateFolder   = $folder;	}
	
    
    
    
    public  function SetTemplateCFolder($folder){   $this->templateCFolder  = $status;	}
	
    
    
    
    public  function SetSmartyPath($folder){        $this->smartyPath  = $folder;	}
	
    
    
    
    public  function SetPreAction($action){  $this->action = $action;  }   
    
    
    
    
    public function SetPreActionWithTemplate($action,$template){
        
         $this->action = $action;
         $this->templateAction = $template; 
    
    }
    
    
    
    
    public function JavaScriptActionInfo(){ $this->javaScriptActionInfo = true; }
    
    
    
    
    public function SmartyPath($path){ $this->smartyPath = $path;  }
    
    
    
    public function AddingRelatedFilesToDOM(){ $this->RelatedFiles = true; }
    

/****************************************
*           WRITE LOG    
*****************************************/  
    
	
	public  static function WriteLog( $data , $Label = "" ){
	   
	   $LabelStart = (empty($Label)) ? "" : "( ".$Label." Starts )";
	   $LabelEnd   = (empty($Label)) ? "" : "( ".$Label." Ends )";
	   $date = gmdate( "l jS \of F Y h:i:s A");
	   
        
	   $file = fopen(self::$logFilePath."debug.log", "a+");
	   fwrite($file, "\n\n /************************$LabelStart****************************/ \n\n");
	   fwrite($file,$date."\n\n\n");
	   fwrite($file, print_r($data,true));
	   fwrite($file, "\n\n /************************$LabelEnd****************************/ \n\n\n\n\n\n");
	   fclose($file);
	   if($file==false) die("unable to create / Write file");
	   
	}    
	
	
	
	
	public static function BuildActionUrl( $action = '' ){
		
		if( empty( $action) ) {
			
			$action = self::GetAction();

		}
		return self::GetApplicationPath() . '?action=' . $action;
		
	}

	
 	public static function GetAction(){ return self::$yAction['_YOTTA_']['ACTION']; }
    
 	
 	
 	
 	public function IsAjax() {
		
		return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'));
	}
 	
    
    	
	
}  // Class Ends


?>
