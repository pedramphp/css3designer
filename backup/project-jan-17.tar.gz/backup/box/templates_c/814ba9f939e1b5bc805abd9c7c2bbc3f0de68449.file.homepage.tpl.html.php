<?php /* Smarty version Smarty-3.0.6, created on 2010-12-31 19:31:40
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/homepage.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:8451755114d1e2f9c58e705-63029609%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '814ba9f939e1b5bc805abd9c7c2bbc3f0de68449' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/homepage.tpl.html',
      1 => 1293823867,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8451755114d1e2f9c58e705-63029609',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id='main-box-wrapper'>
	  <article itemscope>
	    <h2 itemprop="title">Online CSS3 Button Maker Tool</h2>
	      <a href='<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=tools'>
		      <img itemprop="img" 
		           src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
home/button-maker-ad.jpg" 
		           alt="Online CSS3 Button Maker Tool" />
	      </a>
	      <section  class='button-maker-preview' >
		     <p itemprop="content"  > CSS3 BUTTON MAKER 1.0 beta has been released <br /><br />
		  	 create your own button for your website without a need of 
		  	 <i>Javascript</i>, <i>Flash</i> or even <i>Images</i> <br /> try it now 
		  	 <a onClick="_gaq.push(['_trackEvent', 'General', 'Page Link', 'tools']);" href='<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=tools'>CSS3 Button Maker Online Tool</a>
		  	 </p>
		  	 <hr />
		  	<h6> Why using Css3 Button Maker Online Tool:</h6>
		  	<ol>
		  	  <li>  No Need for Flash</li>
		  	  <li>  No Need for Javascript <span class='gray'>( no more dealing with js code to tweak your button )</span</li>
		  	  <li>  No Need for Images <span class='gray'>( Photoshop - images makes our site load slower)</span</li>
		  	  <li>  Faster Websites - by using the browsers native built in code we end up having faster websites</li>
		  	  <li>  Write more reliable and advanced css code </li>
		  	</ol>
		  	<h6>Css3 Button Maker Online Tools Features are listed below</h6>
			  <ul>
			    <li> - Create your own button and get your CSS code.</li>
			    <li> - Ability to create different modes of your button <span class='gray'>( Link, Hover, Visited, Active ) </span></li>
			    <li> - Border Shadow </li>
			    <li> - Round Corner </li>
			    <li> - Gredient Background </li>
			    <li> - Text Shadow </li>
			    <li> - and many many more feature...</li>
			    
			  </ul>
		  </section>	 

	  </article>
	  
</div>