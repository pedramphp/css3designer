<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:12:12
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/_settings/meta.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:11795768004d198dccb63da2-69364048%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f4f0061b0865005d1766fd7762ac2429eae9fee7' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/_settings/meta.tpl.html',
      1 => 1293335575,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11795768004d198dccb63da2-69364048',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="description" content="Css3 designer provides best css3 techniques for web developers and designers . we also support html5 and provide online html5 and css3 tools to inhance web development" />
<meta name="author" content="Mahdi Pedramrazi" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;" />
<meta name="title" content="css3designer" />
<meta name="designer" content="Mahdi Pedramrazi , Farzin Fadamin" />
<meta name="copyright" content="Copyright 2010-2011">