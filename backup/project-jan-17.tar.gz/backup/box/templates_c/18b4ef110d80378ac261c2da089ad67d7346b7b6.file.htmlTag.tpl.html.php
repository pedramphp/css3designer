<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:12:12
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/htmlTag.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:1839520174d198dccb4ca73-91335622%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18b4ef110d80378ac261c2da089ad67d7346b7b6' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/htmlTag.tpl.html',
      1 => 1293354626,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1839520174d198dccb4ca73-91335622',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="ie6 ie"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7 ie"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8 ie"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="ie9 ie"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<!--<![endif]-->