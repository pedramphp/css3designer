<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:12:12
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/copyright.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:13704998094d198dccf37bb5-92723638%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7871f61aedd6b647a0c46f8c39425ceefe497277' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/copyright.tpl.html',
      1 => 1293415022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13704998094d198dccf37bb5-92723638',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <section itemscope id='copyright' class='miniRoundedCorner2'>
	  <aside class='copyright-txt'>
	  	&copy; 2010 - All rights reserved by 
	  	<a title="Mexo LLC." href="http://mexo.co" itemprop="url" title='Mexo LLC ( Web Development Compnay )' >mexo.co</a>
	  </aside>
	  <aside class='footer-logo'>
	    <a title="http://css3designer.com" href="./" itemprop="url">
	      <img itemprop="img" src='<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/copyright/logo-css3-small.png");?>
' alt="CSS3 Logo" />
	    </a>
	  </aside>
	  <figure class='clearfix'></figure>
    </section>