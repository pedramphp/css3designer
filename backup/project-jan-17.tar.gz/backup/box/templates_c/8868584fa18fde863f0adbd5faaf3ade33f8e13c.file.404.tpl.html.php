<?php /* Smarty version Smarty-3.0.6, created on 2010-12-29 20:04:37
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/404.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:2891465484d1b945537e2e1-42418836%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8868584fa18fde863f0adbd5faaf3ade33f8e13c' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/404.tpl.html',
      1 => 1293509649,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2891465484d1b945537e2e1-42418836',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div style=' text-align:center; margin-top:200px; font-size:30px'>Path doesn't Exist	</div>