<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:12:13
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/google/googleAnalytics.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:9099218144d198dcd099b90-37858212%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a9a50d4ee2487d9932ce79f257f4ca7b82cb12c' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/google/googleAnalytics.tpl.html',
      1 => 1293514981,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9099218144d198dcd099b90-37858212',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">

 var _gaq = _gaq || [];

 _gaq.push(['_setAccount', 'UA-19296890-1']);

 _gaq.push(['_trackPageview']);

 (function() {

    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

 })();

</script>