<?php /* Smarty version Smarty-3.0.6, created on 2010-12-30 00:29:21
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/twitter.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:18438641944d1bd26193bee5-40246686%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2f7ab625715796361aa616f1bdffa8306fb44d10' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/actions/default/twitter.tpl.html',
      1 => 1293668858,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18438641944d1bd26193bee5-40246686',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
