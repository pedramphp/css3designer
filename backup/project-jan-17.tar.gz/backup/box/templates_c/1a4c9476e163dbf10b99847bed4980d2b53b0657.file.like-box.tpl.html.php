<?php /* Smarty version Smarty-3.0.6, created on 2010-12-29 04:58:39
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/fb/like-box.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:11565339204d1abfff92c0a1-66808427%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a4c9476e163dbf10b99847bed4980d2b53b0657' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/fb/like-box.tpl.html',
      1 => 1293598709,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11565339204d1abfff92c0a1-66808427',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<fb:like-box href="http://www.facebook.com/pages/CSS3-Designer/156002434435899" width="210" colorscheme="dark" show_faces="true" stream="false" header="false"></fb:like-box>

