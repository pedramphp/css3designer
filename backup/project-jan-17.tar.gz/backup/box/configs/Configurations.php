<?php 

setlocale(LC_MONETARY, 'en_US');


?>