<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 00:39:01
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/onoff.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:21239598554d1931a5d7d7a1-72048858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1684448c94467529a8949d36e7039d91768b8ab4' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/onoff.tpl.html',
      1 => 1293496099,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21239598554d1931a5d7d7a1-72048858',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
                  <section class='onoff' data-lineargredient="true"></section>