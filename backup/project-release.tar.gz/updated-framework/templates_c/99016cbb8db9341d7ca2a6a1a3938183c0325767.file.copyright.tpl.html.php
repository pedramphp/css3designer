<?php /* Smarty version Smarty-3.0.6, created on 2010-12-27 01:57:10
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/copyright.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:2203991964d17f276d50600-40561909%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '99016cbb8db9341d7ca2a6a1a3938183c0325767' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/copyright.tpl.html',
      1 => 1293415022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2203991964d17f276d50600-40561909',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <section itemscope id='copyright' class='miniRoundedCorner2'>
	  <aside class='copyright-txt'>
	  	&copy; 2010 - All rights reserved by 
	  	<a title="Mexo LLC." href="http://mexo.co" itemprop="url" title='Mexo LLC ( Web Development Compnay )' >mexo.co</a>
	  </aside>
	  <aside class='footer-logo'>
	    <a title="http://css3designer.com" href="./" itemprop="url">
	      <img itemprop="img" src='<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/copyright/logo-css3-small.png");?>
' alt="CSS3 Logo" />
	    </a>
	  </aside>
	  <figure class='clearfix'></figure>
    </section>