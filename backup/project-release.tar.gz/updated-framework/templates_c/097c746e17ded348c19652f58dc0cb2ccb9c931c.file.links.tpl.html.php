<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 06:58:11
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/links.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:1010962624d198a83e92d30-89865476%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '097c746e17ded348c19652f58dc0cb2ccb9c931c' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/links.tpl.html',
      1 => 1293519484,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1010962624d198a83e92d30-89865476',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
		<aside>
		  <nav itemscope>
		    <ul>
			  <li id='footer-title'><span class='members' itemprop="teamMembers">Team members</span></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=about#Mahdi" ><span itemprop="name">Mahdi Ped
			  ram Razi</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=about#Hamid" ><span itemprop="name">Hamid Reza Rahimi</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=about#Farzin"><span itemprop="name">Farzin Fadamin</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=about#Scott"><span itemprop="name">Scott Haselton</span></a></li>
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li id='footer-title'><span class='tools'>Recent tools</span></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=tools" target="_blank">CSS3 button maker</a></li>
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li id='footer-title'><span class='favorite'>Favorite</span></li>
			  <li><a href="http://html5doctor.com" target="_blank">HTML5 Doctor</a></li>
			  <li><a href="http://css3.info" target="_blank">CSS3 Info</a></li>
			  <li><a href="http://css-tricks.com" target="_blank">CSS Tricks</a></li>
			  <li><a href="http://html5boilerplate.com" target="_blank">HTML5 boilerplace</a></li>
			  <li><a href="http://hremysharp.com" target="_blank">Remy Sharp</a></li>
			  <li><a href="http://webdesignerwall.com/" target="_blank">Webdesigner Wall</a></li>
			  
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li id='footer-title'><span class='tutorial'>Tutorial</span></li>
		      <li> Nothing Found</li>
			</ul>
		  </nav>
		</aside>