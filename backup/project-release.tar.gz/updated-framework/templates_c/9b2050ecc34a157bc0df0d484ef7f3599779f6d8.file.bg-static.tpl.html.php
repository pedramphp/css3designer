<?php /* Smarty version Smarty-3.0.6, created on 2010-12-27 01:59:00
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/bg-static.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:12935661264d17f2e4b43639-17619068%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b2050ecc34a157bc0df0d484ef7f3599779f6d8' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/bg-static.tpl.html',
      1 => 1293415140,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12935661264d17f2e4b43639-17619068',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
        <img src='<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
coderman.png' class='oldCoder' width='1116' height='608' alt='old coder is our symbol' />
        <a href="http://www.w3.org/TR/html5/" target="_blank" title='we support html5'>  
          <img src='<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
html5-support.png' class='supportTag' width='112' height='112' alt='we support html5' />
        </a>