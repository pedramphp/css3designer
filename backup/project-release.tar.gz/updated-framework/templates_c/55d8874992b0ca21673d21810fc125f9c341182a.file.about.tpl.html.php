<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 06:43:13
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/about.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:19446627994d198701a66235-10098377%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '55d8874992b0ca21673d21810fc125f9c341182a' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/about.tpl.html',
      1 => 1293518593,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19446627994d198701a66235-10098377',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id='main-box-wrapper'  class='aboutus'>
	  <section id="breadcrumb" class="clearfix">
	    <a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
" >Home</a>
		<span> / About</span>
	  </section>
	  <section class="clearfix">
	    <article itemscope id="about-members">
		  <h2>About us</h2>
		  <p>Our team members are <span itemprop="name">Mahdi PedramRazi</span>, <span itemprop="name">HamidReza Rahimi</span>, <span itemprop="name">Farzin Fadamin</span>, <span itemprop="name">Scott Haselton</span>....</p>
		  <h2>Our team members</h2>
		  <section itemscope class="clearfix"><aside><img itemprop="photo" src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
about/mahdi.jpg" alt="Mahdi Pedramrazi" /></aside><aside class='person-content'><h5 itemprop="name" id='Mahdi'>Mahdi PedramRazi</h5><h6>Lead / Core Developer (  <a href='http://mahdipedram.com' target="_blank">mahdi pedram</a> )</h6>
		      <p>
		  		I'm Both Front-end and Back-end Developer living in Virginia,USA<br /> 
		  		I'm a software engineer for <a href='http://www.networksolutions.com'>Network Solutions LLC</a> 
		  		<br />co-founder of <a href='http://www.jquerytoolkit.com' title='think modular with jQuery'>jQuery Toolkit</a>.<br />
		  		and co-founder of <a href='http://www.mexo.com' title='leading company in web development'>Mexo</a>.<br />
		  		 Breaking down a most complicated web app to bunch of small meaningful peice of codes are part of my experties.
		  		 Most of my time I find myself coding insanely with my macbook. listening to trance songs. <br />
		  		 When I'm not coding, I'm CODING ( Playing Call of duty - COD ) <br />
		  		 I'm alive to code.
		      </p>
		    </aside>
		  </section>
		  <section itemscope class="clearfix"><aside><img itemprop="photo" src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
about/hamid.jpg" alt="Hamid-reza Rahimi" /></aside><aside class='person-content'><h5 itemprop="name" id='Hamid'>HamidReza Rahimi</h5><h6>Core Developer</h6><p>I am the cofounder of Mexo Co. located in CA, USA and one of the most skilled front-end developers of the time (!!!). When I'm not doing any CSS or jQuery ( Does it really happen?), I like playing games and study about web usability. Wanna know me better? why not following me on <a href="http://www.twitter.com/hamidrahimi">twitter</a>! ;)</p></aside></section>
		  <section itemscope class="clearfix"><aside><img itemprop="photo" src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
about/farzin.jpg" alt="Farzin Fadamin" /></aside><aside class='person-content'><h5 itemprop="name" id='Farzin'>Farzin Fadamin</h5><h6>Front-end Developer</h6><p>I think it should better to say I'm a web designer not just a designer, as always I'm saying many of designers can make every sketches in Photoshop and other tools like that and make a fabulous poster but, not all of them can make them a perfect website ! Anyway I'm believing myself and be sure you will too very soon ;)</p></aside></section>
		  <section itemscope class="clearfix"><aside><img itemprop="photo" src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
about/scott.jpg" alt="Scott Haselton" /></aside><aside class='person-content'><h5 itemprop="name" id='Scott'>Scott Haselton</h5><h6>Core Developer</h6><p>A programmer in pursuit of code perfection.  Seeking the most compact, yet elegant solution possible in every situation. </p></aside></section>
		</article>
		<article>
		  <h2>About our tools</h2>
		  <p>Among all the various types of tools we expose in this website, CSS3 button maker is the most professional one which enables you to create any kind of possible ( impossibe?) button in CSS3 codes. We're constantly working on realization of other tools for the web developers all over the world.</p>
		</article>
	
		<article>
		  <h2>What's our goal</h2>
		  <p> 
			CSS3 Designer Goal is to provide the best CSS3 and HTML5 techniques,online tools and tutorials for all web developers and designers around the world. 
		  </p>
		</article>
		
	  </section>
</div>