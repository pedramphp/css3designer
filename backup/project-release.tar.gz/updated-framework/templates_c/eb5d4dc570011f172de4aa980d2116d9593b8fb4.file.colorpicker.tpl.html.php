<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 00:39:01
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/colorpicker.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:19515176984d1931a5ce9130-31753135%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb5d4dc570011f172de4aa980d2116d9593b8fb4' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/colorpicker.tpl.html',
      1 => 1293496444,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19515176984d1931a5ce9130-31753135',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class='<?php echo $_smarty_tpl->getVariable('colorpicker')->value;?>
 colorPicker'>
  <div class='<?php echo $_smarty_tpl->getVariable('colorpicker')->value;?>
In colorPickerIn'>
    <div class='<?php echo $_smarty_tpl->getVariable('colorpicker')->value;?>
Inner colorPickerInner' ></div>
  </div>
</div>
