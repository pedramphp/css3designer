<?php /* Smarty version Smarty-3.0.6, created on 2010-12-26 04:11:24
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/_settings/link.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:13888862244d16c06c69ee68-20330012%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0359e6bc68dda5f1d543736153c6e4d1d189ec1c' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/_settings/link.tpl.html',
      1 => 1293336577,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13888862244d16c06c69ee68-20330012',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
<link rel="stylesheet" type="text/css" href="style/reset.css?v=1" />
<link rel="stylesheet" type="text/css" href="style/rules.css?v=1" />
<!-- For the less-enabled mobile browsers like Opera Mini -->
<link rel="stylesheet" media="handheld" href="style/handheld.css?v=1" />
<link rel="stylesheet" type="text/css" href="style/style.css?v=1" />
<link rel="stylesheet" type="text/css" href="style/footer.css?v=1" />
