<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 03:29:42
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/upgradeBrowser.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:16153769974d1959a68f3608-46609559%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5582214a26b8e51990fc23f75247e63483db8d6f' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/upgradeBrowser.tpl.html',
      1 => 1293506953,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16153769974d1959a68f3608-46609559',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id='main-box-wrapper'>
	  <section id="breadcrumb" class="clearfix">
	    <a title="Home" href='<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
'>Home</a>
		<span> / </span>
		<a title="Tools" href='<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=tools'>Tools</a>
		<span> / Button maker</span>
	  </section>
	  <h2>Button maker</h2>
	  <div>
	  	please update your browser  
	  	<a href="http://www.getfirefox.net">
	  	  <img border="0" alt="Firefox 3" title="Firefox 3" src="http://sfx-images.mozilla.org/affiliates/Buttons/firefox3/110x32_best-yet.png"/>
	  	</a>
	  	in order to work with css3 button maker online tools.
	  </div>
</div>	  