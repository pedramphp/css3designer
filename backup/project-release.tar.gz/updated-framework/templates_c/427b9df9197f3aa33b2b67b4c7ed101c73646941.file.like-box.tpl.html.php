<?php /* Smarty version Smarty-3.0.6, created on 2010-12-27 03:29:28
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/fb/like-box.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:5705076084d180818434954-96005727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '427b9df9197f3aa33b2b67b4c7ed101c73646941' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/fb/like-box.tpl.html',
      1 => 1293420490,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5705076084d180818434954-96005727',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
<fb:like-box href="http://www.facebook.com/pages/CSS3-Designer/156002434435899" width="210" colorscheme="dark" show_faces="true" stream="false" header="false"></fb:like-box>

