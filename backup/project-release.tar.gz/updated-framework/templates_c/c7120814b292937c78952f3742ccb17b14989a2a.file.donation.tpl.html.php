<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 00:39:01
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/donation.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:7383645534d1931a58afe33-16520288%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c7120814b292937c78952f3742ccb17b14989a2a' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/tools/buttonMaker/donation.tpl.html',
      1 => 1293495708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7383645534d1931a58afe33-16520288',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" class='donation'>
<input type="hidden" name="cmd" value="_donations">
<input type="hidden" name="business" value="admin@css3designer.com">
<input type="hidden" name="lc" value="US">
<input type="hidden" name="item_name" value="Css3 Designer">
<input type="hidden" name="no_note" value="0">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="bn" value="PP-DonationsBF:donation.png:NonHostedGuest">
<input type="image" src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
paypal/donation.png" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
