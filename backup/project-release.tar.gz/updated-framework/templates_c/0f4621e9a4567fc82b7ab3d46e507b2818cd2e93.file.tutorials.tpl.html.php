<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 03:30:12
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/tutorials.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:8323710744d1959c4595c32-09946078%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0f4621e9a4567fc82b7ab3d46e507b2818cd2e93' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/tutorials.tpl.html',
      1 => 1293506222,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8323710744d1959c4595c32-09946078',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id='main-box-wrapper' >
  <section id="breadcrumb" class="clearfix">
    <a title="Home" href='<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
'>Home</a>
	<span> / Tutorials</span>
  </section>
  <h2>Tutorials</h2>
  <figure style="margin-top:50px" class="alignCenter">
    <img src="<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
tutorials/alert-under-construction.png" alt="we're working on tutorials page">
  </figure>
</div>