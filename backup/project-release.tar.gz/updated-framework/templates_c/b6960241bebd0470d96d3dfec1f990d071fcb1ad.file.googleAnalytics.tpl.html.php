<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 05:43:39
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/google/googleAnalytics.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:2281135694d19790b601233-92196185%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b6960241bebd0470d96d3dfec1f990d071fcb1ad' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/google/googleAnalytics.tpl.html',
      1 => 1293514981,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2281135694d19790b601233-92196185',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<script type="text/javascript">

 var _gaq = _gaq || [];

 _gaq.push(['_setAccount', 'UA-19296890-1']);

 _gaq.push(['_trackPageview']);

 (function() {

    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

 })();

</script>