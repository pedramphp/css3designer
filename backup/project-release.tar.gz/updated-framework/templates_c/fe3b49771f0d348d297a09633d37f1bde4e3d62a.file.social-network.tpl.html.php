<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 06:36:01
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/social-network.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:11344879764d19855196c4d5-13773268%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe3b49771f0d348d297a09633d37f1bde4e3d62a' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/social-network.tpl.html',
      1 => 1293518157,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11344879764d19855196c4d5-13773268',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
	  <section id='social-networks'>
		<figure class='footer-bg'></figure>
		<div itemscope class='footer-wrap'>
		  <aside class='footer-twitter relative'>
		    <div class='tweet-sign'>
		     <a title="<?php echo $_smarty_tpl->getVariable('SiteData')->value['socialLinks']['twitter']['title'];?>
" href="<?php echo $_smarty_tpl->getVariable('SiteData')->value['socialLinks']['twitter']['url'];?>
" target='_blank' >
		       latest tweet
		     </a>
		    </div>
		    <div class='tweet-bx miniRoundedCorner clearfix'>
			  <article itemprop="tweet">Merry Christmas , Css3 Designer has been Launched</article>
			  <a title="Next tweet" href="javascript:void(0)" class='nxt hideText'>next</a>
			  <a title="Previous tweet" href="javascript:void(0)" class='prv hideText'>prev</a>
			</div>
		  </aside>
		  <aside class='other-socials'>
		    <div class='footer-facebook js-link' data-url='<?php echo $_smarty_tpl->getVariable('SiteData')->value['socialLinks']['facebook']['url'];?>
' title='<?php echo $_smarty_tpl->getVariable('SiteData')->value['socialLinks']['facebook']['title'];?>
'>
				<iframe src="http://www.facebook.com/plugins/like.php?href=www.css3designer.com;layout=standard&amp;show_faces=false&amp;width=auto&amp;action=like&amp;font&amp;colorscheme=light&amp;height=60" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:250px; height:60px;" allowTransparency="true"></iframe>
		    </div>
			<a title="Rss feed" href="javascript:void(0);" itemprop="url" class='footer-rss'>rss</a>
		  </aside>
		</div>
	  </section>