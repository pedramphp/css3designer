<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 05:12:43
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/ads.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:6735274414d1971cb684306-16852128%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4459f529568799ed0808fd5d4f690f8112304564' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/ads.tpl.html',
      1 => 1293513162,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6735274414d1971cb684306-16852128',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id='sidebar-section'>
<?php $_template = new Smarty_Internal_Template(($_smarty_tpl->getVariable('includeTemplate')->value).("fb/like-box.tpl.html"), $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php $_template->updateParentVariables(0);?><?php unset($_template);?>	

</div>		