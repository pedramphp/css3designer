<?php /* Smarty version Smarty-3.0.6, created on 2010-12-26 23:31:35
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/books.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:957719454d17d0577b9c27-14023114%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e9c13aa27f93138a197fa6af0d1bcdf5df9b5225' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/books.tpl.html',
      1 => 1293406252,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '957719454d17d0577b9c27-14023114',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
		<nav class='footer-wrap'>
		  <h5 id='footer-title'><span class='books'>Books that we recommend</span></h5>
		  <ul>		    
		    <li itemscope itemtype="http://www.amazon.com/HTML5-Designing-Internet-Applications-Visualizing/dp/0240813286" itemid="urn:isbn:978-0240813288">
			  <a target='_blank' title="HTML5 - Designing Rich Internet Applications" href="http://www.amazon.com/HTML5-Designing-Internet-Applications-Visualizing/dp/0240813286">
			    <img itemprop="photo" src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("books/book_1.jpg");?>
" alt="HTML5-Designing_Rich_Internet_Applications Book" />
			  </a>
			  <span>
			    <b itemprop="title">HTML5 - Designing Rich Internet Applications</b>
			    <a  target='_blank' title="Matthew David" href="http://www.amazon.com/Matthew-David/e/B0032E2O0K/ref=ntt_athr_dp_pel_1" itemprop="author">Matthew David</a>
			  </span>
			</li>
		    <li itemscope itemtype="http://www.amazon.com/gp/product/0321687299/ref=pd_lpo_k2_dp_sr_2?pf_rd_p=486539851&pf_rd_s=lpo-top-stripe-1&pf_rd_t=201&pf_rd_i=0240813286&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=0D1BN44HH2GXGZA85G5Q" itemid="urn:isbn:978-1430228745">
			  <a target='_blank' title="Introduction HTML5" href="http://www.amazon.com/gp/product/0321687299/ref=pd_lpo_k2_dp_sr_2?pf_rd_p=486539851&pf_rd_s=lpo-top-stripe-1&pf_rd_t=201&pf_rd_i=0240813286&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=0D1BN44HH2GXGZA85G5Q">
			    <img itemprop="photo" src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("books/book_2.jpg");?>
" alt="Introduction_HTML5 Book" />
			  </a>
			  <span>
			    <b itemprop="title">Introduction HTML5</b>
			    <a target='_blank' title="Bruce Lawson" href="http://www.amazon.com/s/ref=ntt_athr_dp_sr_1?_encoding=UTF8&sort=relevancerank&search-alias=books&field-author=Bruce%20Lawson" itemprop="author">Bruce Lawson</a> and 
				<a target='_blank' title="Remy Sharp" href="http://www.amazon.com/s/ref=ntt_athr_dp_sr_2?_encoding=UTF8&sort=relevancerank&search-alias=books&field-author=Remy%20Sharp" itemprop="author">Remy Sharp</a>
			  </span>
	        </li>
		    <li itemscope itemtype="http://www.amazon.com/HTML5-Up-Running-Mark-Pilgrim/dp/0596806027/ref=sr_1_1?s=books&ie=UTF8&qid=1292604942&sr=1-1" itemid="urn:isbn:978-0596806026">
			  <a target='_blank' title="HTML5 - up and running" href="http://www.amazon.com/HTML5-Up-Running-Mark-Pilgrim/dp/0596806027/ref=sr_1_1?s=books&ie=UTF8&qid=1292604942&sr=1-1">
			    <img itemprop="photo" src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("books/book_3.jpg");?>
" alt="HTML5-up_and_running Books" />
			  </a>
			  <span>
			    <b itemprop="title">HTML5 - up and running</b>
			    <a target='_blank' title="Mark Pilgrim" href="http://www.amazon.com/Mark-Pilgrim/e/B001ITVVN2/ref=ntt_athr_dp_pel_1" itemprop="author">Mark Pilgrim</a>
			  </span>
			</li>
		    <li itemscope itemtype="http://www.amazon.com/Beginning-HTML5-CSS3-Generation-Standards/dp/1430228741/ref=sr_1_1?ie=UTF8&s=books&qid=1292604964&sr=1-1" itemid="urn:isbn:978-1430228745">
			  <a target='_blank' title="Beginning HTML5 and CSS3" href="http://www.amazon.com/Beginning-HTML5-CSS3-Generation-Standards/dp/1430228741/ref=sr_1_1?ie=UTF8&s=books&qid=1292604964&sr=1-1">
			    <img itemprop="photo" src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("books/book_4.jpg");?>
" alt="Beginning_HTML5_and_CSS3 Book" />
			  </a>
			  <span>
			    <b itemprop="title">Beginning HTML5 and CSS3:Next Generation Web Standards</b>
			    <a target='_blank' title="Christopher Murphy" href="http://www.amazon.com/s/ref=ntt_athr_dp_sr_1?_encoding=UTF8&sort=relevancerank&search-alias=books&field-author=Christopher%20Murphy" itemprop="author">Christopher Murphy</a> and 
			    <a target='_blank' title="Richard Clark" href="http://www.amazon.com/s/ref=ntt_athr_dp_sr_2?_encoding=UTF8&sort=relevancerank&search-alias=books&field-author=Richard%20Clark" itemprop="author">Richard Clark</a> and 
			    <a target='_blank' title="Oli Studholme" href="http://www.amazon.com/s/ref=ntt_athr_dp_sr_3?_encoding=UTF8&sort=relevancerank&search-alias=books&field-author=Oli%20Studholme" itemprop="author">Oli Studholme</a>
			  </span>
			</li>
		  </ul>
		</nav>