<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 04:22:25
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/sponsers.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:8366518914d1966012acbf1-28730140%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '156b7e816dc8f97fdb629bbc002c31451c271e1a' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/footer/sponsers.tpl.html',
      1 => 1293510143,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8366518914d1966012acbf1-28730140',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
		<aside>
		  <a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=about#Farzin" title="Farzin Fadamin ( Web Designer )" itemprop="url">
		    <img src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/logo-farzin.png");?>
" alt="farzin signature" />
		  </a>
		</aside>
		<aside>
		  <a href="http://www.mexo.co" title="Mexo LLC." itemprop="url" target="_blank">
		    <img src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/logo-mexo.png");?>
" alt="Mexo Web development company" />
		  </a>
		  <p>Mexo is a leading company in web development,
		   building Rich internet Application, and also support small and large businesses in web development.
		    <a href="javascript:void(0)">[more]</a>
		  </p>
		</aside>
		<aside>
		  <a href="http://jquerytoolkit.com" title="Our Partner is jQuerytoolkit" itemprop="url" target="_blank">
		    <img src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/logo-jt.png");?>
" alt="jQueryToolkit Website" />
		  </a>
		</aside>
		<aside>
		  <a href="http://mediatemple.net" title="Hosted by MediaTemple" itemprop="url" target="_blank">
		    <img src="<?php echo ($_smarty_tpl->getVariable('imagePath')->value).("footer/logo-mt.png");?>
" alt="Media temple hosts css3designer" />
		  </a>
		</aside>