<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 04:14:11
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/404.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:11839073924d196413618035-81824731%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '50826fe55e31ea3d0c9a5794c1bc365672083602' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/actions/default/404.tpl.html',
      1 => 1293509649,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11839073924d196413618035-81824731',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div style=' text-align:center; margin-top:200px; font-size:30px'>Path doesn't Exist	</div>