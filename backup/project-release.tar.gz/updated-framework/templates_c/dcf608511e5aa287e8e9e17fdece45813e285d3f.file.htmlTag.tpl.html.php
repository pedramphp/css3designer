<?php /* Smarty version Smarty-3.0.6, created on 2010-12-26 09:18:10
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/htmlTag.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:21087490664d170852041e22-17198259%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dcf608511e5aa287e8e9e17fdece45813e285d3f' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/updated-framework/templates/includes/default/htmlTag.tpl.html',
      1 => 1293354626,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21087490664d170852041e22-17198259',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="ie6 ie"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7 ie"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8 ie"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="ie9 ie"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<!--<![endif]-->