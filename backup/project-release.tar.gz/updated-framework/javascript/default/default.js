$(document).ready(function(){
	
	core.activateLinks();
	core.gotop();
	
});


var core = {};
core.activateLinks = function(){
	
	$('.js-link').click(function(){
		window.location.href = $(this).data('url');
	})
	
};


core.gotop = function(){
	$('.gotop').click(function(){
		$.gotop();		
	});
}