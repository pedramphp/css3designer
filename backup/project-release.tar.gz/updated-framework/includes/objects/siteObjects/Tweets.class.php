<?php 

	require_once(LiteFrame::GetFileSystemPath()."includes/modules/twitter/Twitter.class.php");
	
	class Tweets extends SiteObject {
		
		public function __construct(){
			parent::__construct();
		}
		
		
		public function process(){
			/*
			$twitter = new Twitter('pedramphp','khazokhil');
			// Show public timeline
			$xml = $twitter->getFriendsTimeline();
			
			$twitter_status = new SimpleXMLElement($xml);
			SiteHelper::Debug("twitter",$twitter_status);
			*/
			$this->results = "sdsd";			
		}
		
	}


?>