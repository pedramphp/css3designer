#! /bin/sh
rm -rf templates_c/*
rm -rf log/*
rm -rf image_mirroring_data/*

chmod "a+w" templates_c/
chmod "a+w" log/
