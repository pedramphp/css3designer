<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:16:00
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/tools/buttonMaker/onoff.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:19634300954d198eb04eb413-14496273%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0f186f04930e71418e333d03f91064533a2bc6ef' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/tools/buttonMaker/onoff.tpl.html',
      1 => 1293496099,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19634300954d198eb04eb413-14496273',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
                  <section class='onoff' data-lineargredient="true"></section>