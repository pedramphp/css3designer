<?php /* Smarty version Smarty-3.0.6, created on 2010-12-28 07:12:12
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/bg-static.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:5983102154d198dccbe0ad4-66916837%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f648109265c6a483ae49262786c8bca528d542e3' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/bg-static.tpl.html',
      1 => 1293415140,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5983102154d198dccbe0ad4-66916837',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
        <img src='<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
coderman.png' class='oldCoder' width='1116' height='608' alt='old coder is our symbol' />
        <a href="http://www.w3.org/TR/html5/" target="_blank" title='we support html5'>  
          <img src='<?php echo $_smarty_tpl->getVariable('imagePath')->value;?>
html5-support.png' class='supportTag' width='112' height='112' alt='we support html5' />
        </a>