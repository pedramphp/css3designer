<?php /* Smarty version Smarty-3.0.6, created on 2011-01-04 17:13:53
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/footer/links.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:16580059524d235551e73150-84266913%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '966f2605cedcb1868df052eb391a39f7df692e26' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/footer/links.tpl.html',
      1 => 1294161231,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16580059524d235551e73150-84266913',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
		<aside>
		  <nav itemscope>
		    <ul>
			  <li class='footer-title'><span class='members' itemprop="teamMembers">Team members</span></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('SiteData')->value['mainNav']['about']['url'];?>
?#Mahdi" ><span itemprop="name">Mahdi Ped
			  ram Razi</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('SiteData')->value['mainNav']['about']['url'];?>
?#Hamid" ><span itemprop="name">Hamid Reza Rahimi</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('SiteData')->value['mainNav']['about']['url'];?>
?#Farzin"><span itemprop="name">Farzin Fadamin</span></a></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('SiteData')->value['mainNav']['about']['url'];?>
?#Scott"><span itemprop="name">Scott Haselton</span></a></li>
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li class='footer-title'><span class='tools'>Recent tools</span></li>
			  <li><a href="<?php echo $_smarty_tpl->getVariable('applicationPath')->value;?>
?action=tools" target="_blank">CSS3 button maker</a></li>
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li class='footer-title'><span class='favorite'>Favorite</span></li>
			  <li><a href="http://html5doctor.com" target="_blank">HTML5 Doctor</a></li>
			  <li><a href="http://css3.info" target="_blank">CSS3 Info</a></li>
			  <li><a href="http://css-tricks.com" target="_blank">CSS Tricks</a></li>
			  <li><a href="http://html5boilerplate.com" target="_blank">HTML5 boilerplace</a></li>
			  <li><a href="http://remysharp.com" target="_blank">Remy Sharp</a></li>
			  <li><a href="http://webdesignerwall.com/" target="_blank">Webdesigner Wall</a></li>
			  
			</ul>
		  </nav>
		</aside>
		<aside>
		  <nav>
		    <ul>
		      <li class='footer-title'><span class='tutorial'>Tutorial</span></li>
		      <li> Nothing Found</li>
			</ul>
		  </nav>
		</aside>