<?php /* Smarty version Smarty-3.0.6, created on 2010-12-29 04:29:20
         compiled from "/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/fb/comment-box.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:8378003544d1ab920378aa2-67436744%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9fe366e2c194c60b801382391de294f964a3c8e6' => 
    array (
      0 => '/var/www/vhosts/css3designer.com/httpdocs/templates/includes/default/fb/comment-box.tpl.html',
      1 => 1293596860,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8378003544d1ab920378aa2-67436744',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="fb-root"></div>
<fb:comments xid="12" numposts="15" width="700" publish_feed="true"></fb:comments>